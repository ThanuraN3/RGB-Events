<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
<input type="checkbox" id="check">
    <div class="sidebar">
      <header>RGB Admin</header>
      <a href="home.php" >
        <i class="fas fa-qrcode"></i>
        <span>Blog</span>
      </a>
      <a href="gallary.php">
         <i class="fas fa-calendar"></i>
        <span>Gallary</span>
      </a>
      
      <a href="seo.php">
        <i class="far fa-question-circle"></i>
        <span>SEO</span>
      </a>
      <a href="advertisement.php">
        <i class="fas fa-sliders-h"></i>
        <span>Advertisements</span>
      </a>
      <a href="overview.php">
        <i class="fas fa-stream"></i>
        <span>Overview</span>
      </a>
      <a href="#">
        <i class="far fa-envelope"></i>
        <span>Contact</span>
      </a>
      <br>
      <br>
      <a href="logout.php">
      <i class="far fa-arrow"></i>
        <span>Log out</span>
      </a>  
    </div>
</body>
</html>